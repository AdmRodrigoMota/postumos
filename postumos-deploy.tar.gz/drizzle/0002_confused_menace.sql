ALTER TABLE `memorial_profiles` MODIFY COLUMN `birthDate` datetime;--> statement-breakpoint
ALTER TABLE `memorial_profiles` MODIFY COLUMN `deathDate` datetime;